 ## Autoscript VPS created by [Telegram: Si Tony](https://t.me/simuncaibetollah):shipit:
 
###### Operating software
:computer:[Putty.exe for PC(64-bit)](https://the.earth.li/~sgtatham/putty/latest/w64/putty.exe)

:phone:[JuiceSSH for Android](https://play.google.com/store/apps/details?id=com.sonelli.juicessh&hl=en)

- SILA ACCEPT (Y/YES) JIKA ADA TAMBAHAN PACKAGE
==============================================================================

# 2017 (support Debian 7 32/64 bit)
```
wget https://raw.githubusercontent.com/syahz86/new/debian7/2017.sh && chmod +x ./2017.sh && ./2017.sh
```
# OPENVPN
```
wget -O openvpn.sh https://raw.githubusercontent.com/syahz86/y/debian7/openvpn.sh && chmod +x openvpn.sh && ./openvpn.sh
```
###### BAIK PUNYA CILOK (COPY & PASTE)
=================================================================================
